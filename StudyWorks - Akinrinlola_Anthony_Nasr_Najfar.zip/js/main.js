$(function () {
  $("#navbar-container").load("/components/navbar.html");
});
console.log("hi");
